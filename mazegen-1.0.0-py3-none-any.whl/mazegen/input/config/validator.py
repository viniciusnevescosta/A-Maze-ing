from collections.abc import Mapping
from typing import cast

from mazegen.input.config.parser import parse_coordinate

Coordinate = tuple[int, int]
ConfigValue = str | int | bool | Coordinate


REQUIRED_CONFIG_KEYS = (
    "WIDTH",
    "HEIGHT",
    "ENTRY",
    "EXIT",
    "OUTPUT_FILE",
    "PERFECT",
)

OPTIONAL_CONFIG_KEYS = ("SEED",)

ALLOWED_CONFIG_KEYS = REQUIRED_CONFIG_KEYS + OPTIONAL_CONFIG_KEYS


class MissingRequiredKeysError(ValueError):
    """Report required configuration keys that are missing."""

    def __init__(self, missing_keys: tuple[str, ...]) -> None:
        """Store the offending keys and build a readable error message."""
        self.missing_keys = missing_keys
        keys = ", ".join(missing_keys)
        key_label: str = "key" if len(missing_keys) == 1 else "keys"
        super().__init__(f"Missing required configuration {key_label}: {keys}")


class UnknownConfigKeysError(ValueError):
    """Report configuration keys that are not supported."""

    def __init__(self, unknown_keys: tuple[str, ...]) -> None:
        """Store the offending keys and build a readable error message."""
        self.unknown_keys = unknown_keys
        keys = ", ".join(unknown_keys)
        key_label: str = "key" if len(unknown_keys) == 1 else "keys"
        super().__init__(f"unknown configuration {key_label}: {keys}")


def validate_required_keys(config: Mapping[str, str]) -> None:
    """Raise MissingRequiredKeysError if required keys are absent."""
    missing_keys: list[str] = []

    for key in REQUIRED_CONFIG_KEYS:
        if key not in config:
            missing_keys.append(key)

    if missing_keys:
        raise MissingRequiredKeysError(tuple(missing_keys))


def validate_unknown_keys(config: Mapping[str, str]) -> None:
    """Raise UnknownConfigKeysError if unsupported keys are present."""
    unknown_keys: list[str] = []

    for key in config:
        if key not in ALLOWED_CONFIG_KEYS:
            unknown_keys.append(key)

    if unknown_keys:
        raise UnknownConfigKeysError(tuple(unknown_keys))


def validate_coordinate_in_bounds(
    key: str,
    coordinate: Coordinate,
    width: int,
    height: int,
) -> None:
    """Raise ValueError if a coordinate is outside the maze."""
    x, y = coordinate

    x_is_valid = 0 <= x < width
    y_is_valid = 0 <= y < height

    if not (x_is_valid and y_is_valid):
        raise ValueError(f"{key} must be inside maze bounds: '{coordinate}'")


def convert_config_coordinates(
    config: Mapping[str, ConfigValue],
) -> dict[str, ConfigValue]:
    """Return a copy with ENTRY and EXIT parsed as integer pairs."""
    converted_config = dict(config)

    for key in ("ENTRY", "EXIT"):
        value = cast(str, config[key])
        converted_config[key] = parse_coordinate(value)

    return converted_config


def validate_config_coordinates(
    config: Mapping[str, ConfigValue],
) -> None:
    """Raise ValueError for out-of-bounds or identical endpoints."""
    width = cast(int, config["WIDTH"])
    height = cast(int, config["HEIGHT"])

    for key in ("ENTRY", "EXIT"):
        coordinate = cast(Coordinate, config[key])

        validate_coordinate_in_bounds(
            key=key,
            coordinate=coordinate,
            width=width,
            height=height,
        )

    entry = cast(Coordinate, config["ENTRY"])
    exit_coordinate = cast(Coordinate, config["EXIT"])

    if entry == exit_coordinate:
        raise ValueError("ENTRY and EXIT must be different coordinates")


def convert_config_dimensions(
    config: Mapping[str, str],
) -> dict[str, ConfigValue]:
    """Convert dimensions to positive integers or raise ValueError."""
    converted_config: dict[str, ConfigValue] = dict(config)

    for key in REQUIRED_CONFIG_KEYS[:2]:
        try:
            value = int(config[key])
        except ValueError as error:
            raise ValueError(
                f"{key} must be an integer: '{config[key]}'"
            ) from error

        if value <= 0:
            raise ValueError(
                f"{key} must be greater than zero: '{config[key]}'"
            )

        converted_config[key] = value
    return converted_config


def convert_config_perfect(
    config: Mapping[str, ConfigValue],
) -> dict[str, ConfigValue]:
    """Convert True or False text to a boolean or raise ValueError."""
    converted_config: dict[str, ConfigValue] = dict(config)
    perfect_value = config["PERFECT"]

    if perfect_value == "True":
        converted_config["PERFECT"] = True
    elif perfect_value == "False":
        converted_config["PERFECT"] = False
    else:
        raise ValueError(
            f"PERFECT must be 'True' or 'False': '{perfect_value}'"
        )
    return converted_config


def convert_config_seed(
    config: Mapping[str, ConfigValue],
) -> dict[str, ConfigValue]:
    """Convert an optional seed to an integer or raise ValueError."""
    converted_config: dict[str, ConfigValue] = dict(config)

    if "SEED" not in config:
        return converted_config

    seed_text = cast(str, config["SEED"])

    try:
        seed_value = int(seed_text)
    except ValueError as error:
        raise ValueError(f"SEED must be an integer: '{seed_text}'") from error

    converted_config["SEED"] = seed_value
    return converted_config
