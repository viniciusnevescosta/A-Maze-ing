"""Maze output file writing."""
